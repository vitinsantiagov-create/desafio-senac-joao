

function formaDePagamento() {
    let formaDePagamento = window.prompt("escolha a forma de pagamento: 1- pagamento à vista , 2- parcelado de 12x; ");

    if (formaDePagamento == "1") {
        let preço = 12500;
        let desconto = preço * 10 / 100;
        let preçoFinal = preço - desconto;
        document.getElementById("resultado").innerHTML = "o desconto é de: R$" + desconto;
        document.getElementById("preco-final").innerHTML = "uma exelente escolha com desconto de 10% o valor fica: R$" + preçoFinal;
    }else if (formaDePagamento == "2") {
      let parcelas =  window.prompt("de quantas parcelas você deseja dividir o valor? (máximo de 12x)");
        let preço = 12500;
        let desconto = preço * 5 / 100 / parcelas;
        let preçoFinal = preço + desconto;
        document.getElementById("resultado").innerHTML = "O desconto é de: R$" + desconto;
        document.getElementById("preco-final").innerHTML = "O seu notebook ficara em (" + parcelas + "x): R$" + preçoFinal;
    }
}
